package com.technoviral.springmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMongoPlaygroundApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMongoPlaygroundApplication.class, args);
	}

}
