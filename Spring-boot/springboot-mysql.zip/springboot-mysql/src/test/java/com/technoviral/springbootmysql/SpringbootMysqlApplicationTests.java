package com.technoviral.springbootmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
